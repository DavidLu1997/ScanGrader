No installation required, unzip and run.
Only one config file available at the moment, config.ini
Only one template available at the moment, ScanGrader50.pdf

How to use:
- Print ScanGrader50.pdf
- Use with multiple choice test
- Scan using scanner and convert to BMP files
- Create answer key(s)
- Add config file to program
- Add answer key(s) to program
- Set answer keys for each file
- Calculate
- See results in results tab
- Export to CSV/TXT

Known issues:
- Export to SQL has not been implemented
- Options currently do not do anything
- Accuracy lacking